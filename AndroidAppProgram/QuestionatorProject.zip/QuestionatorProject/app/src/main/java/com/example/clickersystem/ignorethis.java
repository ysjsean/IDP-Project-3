package com.example.clickersystem;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class ignorethis extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.student_registration_page);
    }
}